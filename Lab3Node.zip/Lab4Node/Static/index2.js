fetch("http://localhost:3000/index2.html", { mode: "cors" }).then((res) => {
  console.log(res);
});
